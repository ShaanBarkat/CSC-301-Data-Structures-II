package puzzlesolver;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;


public class Solve8 {
	
	public static void main(String[] args) throws IOException {
		// All my code should be working correctly to my knowledge, I've changed it a bunch of times and used different implementations. 
		// At this point, I think it's my pathing according to my colleagues and tutors. 
		// So, I made a new project, restarted eclipse, rewrote my code. None of it worked..........
		int rows = 3;//going to be representing the rows
		int cols = 3;//going to be representing the columns 
		int i = 1;
		int p = 1;
		String bfile = args[0];//making a file equal an open array, so our contents of the file have somewhere to be
		System.out.println(bfile);// print the file, file is being used in the arguments; BUT MY PATH REFUSES TO RUN IT CORRECTLY!!
		Scanner sc = new Scanner(new File(bfile));//scanning the input file which is a scramble of numbers I chose that goes from 1-8 with one missing file, being x.
		String[][] barray = new String[cols][rows];//the board is supposed to be a 3by3 with one missing space. The missing space, x is suppose to be 9
		
		Map<Integer, String> arr = new HashMap<Integer, String>();//HashMap acts as a dictionary, we can store our elements in them and format them later on.
		
		
		while(sc.hasNext()){//This read every line in the file, and it keeps going until hits the end.
			arr.put(i, sc.next());
			i++;
		}
		System.out.println(arr.entrySet());//Prints out the HashMap
		for(int a=0; a<cols; a++){//Prints out the 2D array
			for(int b=0; b<rows; b++){// This is printed accordingly to rows and columns
				barray[a][b] = arr.get(p);//allows you get value in the Hash table
				p++;
			}
		}
		for(int u=0; u<cols; u++){
			System.out.println();//Printing out the 2D array in the correct formation 
			for(int l=0; l<rows; l++){
			System.out.print(barray[u][l] + " ");// gives spaces in between each element, should look like 1 2 3
			}																							// 4 x 6
		}																								// 7 5 8
	}
}

