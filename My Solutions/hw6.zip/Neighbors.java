package puzzlesolver;


import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
//import java.io.File;
//import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

public class Neighbors {
	
//I couldn't get my input file to path correctly, but I wanted to continue onto the assignment.
//So I made my own boards..
//Worked with tutor


	public static String[][] MainBoard = {{"8", "3", "7"},{"2","1","5"},{"x","6","4"}};//assortment of numbers in an array to create board

	public static String[][] SameBoard(){
		String[][] dict = new String[3][3];//making formation of board, displayed correctly
		for (int w = 0; w < 3; w++){ 
			dict[w]= Arrays.copyOf(MainBoard[w], MainBoard[1].length);
		}
		return dict;
	}
	public static void main(String args[]) throws Exception{
		System.out.println("Printing original board...");//just some text saying it printing the "original" board
		for(int x = 0; x < MainBoard.length; x++){//it takes the numbers I manually input for board1 and goes through each number
			for(int z = 0; z < MainBoard[0].length; z++){
				System.out.print(MainBoard[x][z] + " ");//prints out the board
			}
			System.out.println();
		}
		
		//There are a total of 9 different places "x" can be placed, the following
				if (MainBoard[0][0].equals("x")){
					//checks position 0,0; if "x" is in that position then use this board
					System.out.println("Neighbor One");
					next(0,0,1,0);
					
					System.out.println("Neighbor Two");
					next(0,0,0,1);
					
				}
				else if (MainBoard[0][1].equals("x")){
					//checks position 0,1; if "x" is in that position then use this board
					System.out.println("Neighbor One");
					next(0,1,1,1);
					
					System.out.println("Neighbor Two");
					next(0,1,0,0);
					
					System.out.println("Neighbor Three");
					next(0,1,0,2);
					
				}
				else if (MainBoard[0][2].equals("x")){
					//checks position 0,2; if "x" is in that position then use this board
					System.out.println("Neighbor One");
					next(0,2,1,2);
					
					System.out.println("Neighbor Two");
					next(0,2,0,1);
					
					System.out.println("Neighbor Three");
				}
				else if (MainBoard[1][0].equals("x")){
					//checks position 1,0; if "x" is in that position then use this board
					System.out.println("Neighbor One");
					next(1,0,1,1);
					
					System.out.println("Neighbor Two");
					next(1,0,0,0);
					
					System.out.println("Neighbor Three");
					next(1,0,2,0);
				}
				else if (MainBoard[1][1].equals("x")){
					//checks position 1,1; if "x" is in that position then use this board
					System.out.println("Neighbor One");
					next(1,1,0,1);
					
					System.out.println("Neighbor Two");
					next(1,1,2,1);
					
					System.out.println("Neighbor Three");
					next(1,1,1,0);
					
					System.out.println("Neighbor Four");
					next(1,1,1,2);
				}	
				else if (MainBoard[1][2].equals("x")){
					//checks position 1,2; if "x" is in that position then use this board
					System.out.println("Neighbor One");
					next(1,2,0,2);
					
					System.out.println("Neighbor Two");
					next(1,2,2,2);
					
					System.out.println("Neighbor Three");
					next(1,2,1,1);
				}
				else if (MainBoard[2][0].equals("x")){
					//checks position 2,0; if "x" is in that position then use this board
					System.out.println("Neighbor One");
					next(2,0,1,0);
					
					System.out.println("Neighbor Two");
					next(2,0,2,1);
					
				}
				else if (MainBoard[2][1].equals("x")){
					//checks position 2,1; if "x" is in that position then use this board
					System.out.println("Neighbor One");
					next(2,1,1,1);
					
					System.out.println("Neighbor Two");
					next(2,1,2,0);
					
					System.out.println("Neighbor Three");
					next(2,1,2,2);
				}
				else if (MainBoard[2][2].equals("x")){
					//checks position 2,2; if "x" is in that position then use this board
					System.out.println("Neighbor One");
					next(2,2,1,2);
					
					System.out.println("Neighbor Two");
					next(2,2,2,1);
					
				}
				else
					System.out.println("No Neighbors Present.");
			
		}
	
		public static void next(int X,int Y,int X1,int Y1){ //coordinate positions
		
		String[][] dict = new String[3][3];//making a 2D array
		
		for (int p = 0; p < 3; p++){
			dict[p]= Arrays.copyOf(MainBoard[p], MainBoard[1].length);//making a copy of all the arrays
		}
			String x = dict[X1][Y1];//making them into strings, so they can be printed
			String y = dict[X][Y];
			
			dict[X][Y] = x;
			dict[X1][Y1] = y;	
			
			for(int o = 0; o < dict.length; o++){
				for(int z = 0; z < dict[0].length; z++){
					System.out.print(dict[o][z] + " ");//printing out the puzzle!
				}
				System.out.println();
			}
			
		}	
}
