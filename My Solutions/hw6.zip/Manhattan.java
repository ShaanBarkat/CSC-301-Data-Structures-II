package puzzlesolver;

public class Manhattan{
	//Manhattan is used to count the amount of moves it will take the "x" to get to it's designated position.
	//For instance, if x is in the position of 1 and need to reach 9 in an board such as x 2 3
}	//																 					 4 5 6
	//																					 7 8 1
	//It would have to move 4 positions to get to its designated position
	