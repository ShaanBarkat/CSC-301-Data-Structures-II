package hw5;
/*

From: https://www.cs.cmu.edu/~adamchik/15-121/lectures/Hashing/hashing.html

Thanks Victor Adamchick at CMU?

184 thousand words: http://www.andrew.cmu.edu/course/15-121/dictionary.txt

All of these words should appear in the dictionary: spinach jagged outspeeded ginned regretfully

...but not these words: Kislenkio Artapuchiness Frisklongolupia

By default, this program spell-checks its own source code.

Your assignment:

1. Add your EXTENSIVE comments explaning how the hashing works in each interesting part of the program.

2. Modify this program to accept a first line argument which is the name of the input file to be spellchecked.

3. Modify this program to accept a second commandline argument which is the name of your own dictionary.

*/


//Author: Shaan Barkat
import java.util.*;
import java.io.*;
import java.net.*;

public class MySpellchecker{
  public static void main(String[] args) throws IOException{ 
    String FileName; //FileName is a string that converts a text file filled with words into string so it can be printed, also acts as first argument 
    String Dictionary = "";// Dictionary is a string that converts a text file filled with words into a string so it can be printed, also acts as second argument
    if (args.length < 1){// if there isn't an argument, check file compiled of nothing
      FileName = new String("MySpellcheckerInput.txt"); // Default: check THIS program
    }
    else if (args.length == 1){//if argument is given one argument, then filename equals that argument 
    	FileName = args[0];
    }
    else{
    	FileName = args[0];// if given two arguments, use both Dictionary and filename
    	Dictionary = args[1];
    }
    System.out.println("Using input file: " + FileName + "\n");//Printing a text alongside filename, in this case being the difference between dictionaries
    HashSet<String> dict = new HashSet<String>();//hashset string variable given as dict, if multiple of same string are inside dictionary, they are discarded and only 1 is kept
    if(args.length <= 1){//if arguments are greater than or equal to 1
    URL url = new URL("http://andrew.cmu.edu/course/15-121/dictionary.txt");
    Scanner sc = new Scanner(url.openStream());//then opens up the url  
    while(sc.hasNext()) dict.add(sc.next());//hasNext, continuously reads each word due to while loop and adds it to the hashset until there aren't any more words in dictionary
    sc.close();// once it does, sc closes
    }
    else{
    	Scanner sc = new Scanner(new File(Dictionary));// else is reads the other dictionary, Dictionary, then does the exact same thing
    	while(sc.hasNext()) dict.add(sc.next());//reads all the words and adds it to the hashset until it can't anymore
        sc.close();// once it does sc closes
    }
 
    System.out.println("These words are not in the dictionary:\n");//prints out text -->
    Scanner sc = new Scanner(new File(FileName));
    while( sc.hasNextLine()){
      String[] tokens = sc.nextLine().split("\\W");//splits the tokens by space and takes out any punctuation and then puts them into an array
      for(String token : tokens)
	if (token.length() > 1 && !dict.contains(token.toLowerCase()))//ultimately, it compares both the input file and the dictionary file
		//and contrasts them, outputting only those tokens(words) that are not in both dictionaries. In my case it was only a few since I used the same 
		//dictionary file and took out only a few words.
	  System.out.println(token);
    }
  }
}
